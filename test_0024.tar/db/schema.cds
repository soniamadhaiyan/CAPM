namespace jnj.pickconfirmation;

using { cuid, managed } from '@sap/cds/common';



type MessageStatus : String(20) enum {
  Received;
  Processing;
  Completed;
  Warning;
  Duplicate;
  Failed;
  HeldForReprocessing;
}

type OperationStatus : String(20) enum {
  Planned;
  Succeeded;
  Failed;
  RolledBack;
  Skipped;
}

type OperationType : String(50) enum {
  PickOneItemWithSalesQuantity;
  PickAndBatchSplitOneItem;
  DeleteDeliveryItem;
  ConfirmPickingOneItem;
  ConfirmPickingAllItems;
}

type PickItemInput : {
  deliveryDocumentItem : String(6);
  sequenceNumber       : String(3);
  material             : String(40);
  plant                : String(4);
  storageLocation      : String(4);
  batch                : String(10);
  pickedQuantity       : Decimal(13,3);
  deliveryQuantityUnit : String(3);
  carrier              : String(6);
}

type PickConfirmationInput : {
  correlationId      : String(80);
  messageType        : String(30);
  qualifier          : String(10);
  deliveryDocument   : String(10);
  carrier            : String(6);
  idempotencyKey     : String(200);
  items              : array of PickItemInput;
}

entity PickConfirmationMessages : cuid, managed {
  correlationId      : String(80) not null;
  messageType        : String(30) not null default 'PICKCONFIRM';
  qualifier          : String(10) not null default 'PIC';
  deliveryDocument   : String(10) not null;
  carrier            : String(6);
  idempotencyKey     : String(200) not null;
  status             : MessageStatus not null default #Received;
  receivedAt         : Timestamp not null;
  processingStartedAt: Timestamp;
  completedAt        : Timestamp;
  errorCode          : String(40);
  errorMessage       : String(1000);
  rollbackCompleted  : Boolean default false;
  items              : Composition of many PickConfirmationItems on items.message = $self;
  operations         : Composition of many PickOperations on operations.message = $self;
}

entity PickConfirmationItems : cuid {
  message              : Association to PickConfirmationMessages;
  deliveryDocumentItem : String(6) not null;
  sequenceNumber       : String(3) not null default '000';
  material             : String(40);
  plant                : String(4);
  storageLocation      : String(4);
  batch                : String(10);
  pickedQuantity       : Decimal(13,3) not null;
  deliveryQuantityUnit : String(3) not null;
  status               : OperationStatus not null default #Planned;
  plannedOperation     : OperationType;
  validationMessage    : String(1000);
}

entity PickOperations : cuid {
  message              : Association to PickConfirmationMessages;
  item                 : Association to PickConfirmationItems;
  operation            : OperationType not null;
  status               : OperationStatus not null default #Planned;
  attemptedAt          : Timestamp;
  completedAt          : Timestamp;
  errorCode            : String(40);
  errorMessage         : String(1000);
}

entity ProcessedMessages {
  key idempotencyKey : String(200);
  correlationId      : String(80) not null;
  deliveryDocument   : String(10) not null;
  outcome            : MessageStatus not null;
  message            : Association to PickConfirmationMessages;
  completedAt        : Timestamp not null;
  expiresAt          : Timestamp;
}

@readonly entity DeliveryContexts : cuid {
  deliveryDocument : String(10) not null;
  actualRoute      : String(6);
  items            : Composition of many DeliveryItemContexts on items.delivery = $self;
}

@readonly entity DeliveryItemContexts : cuid {
  delivery             : Association to DeliveryContexts;
  deliveryDocumentItem : String(6) not null;
  material             : String(40) not null;
  plant                : String(4);
  storageLocation      : String(4);
  batch                : String(10);
  materialIsBatchManaged : Boolean not null default false;
  deliveryQuantity     : Decimal(13,3) not null;
  deliveryQuantityUnit : String(3) not null;
  pickedQuantity       : Decimal(13,3) not null default 0;
  deleted              : Boolean not null default false;
}
