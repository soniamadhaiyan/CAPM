# MARC Pick Confirmation CAP Implementation

Source FSD: `TV-TMP-MT-Design-Specification-RICEFW_JHPZ_158593_MARC_PickConf_S4.docx`

## Implemented scope

- Asynchronous CAP action endpoint for the retained `PICKCONFIRM` / `PIC` contract.
- Message, item, operation, and idempotency persistence.
- Delivery-level serialization.
- Validation for delivery/item keys, material, batch, quantity, and Delivery UoM.
- Selection of:
  - `PickOneItemWithSalesQuantity` for full and short picks.
  - `PickAndBatchSplitOneItem` for `sequenceNumber = 001`.
  - outbound-delivery item deletion for quantity zero.
  - one-item or all-items picking confirmation.
- Duplicate suppression and reprocessing endpoint.
- Transactional mock S/4 adapter suitable for local validation.

## Local payload example

```json
{
  "input": {
    "correlationId": "MARC-2026-0001",
    "messageType": "PICKCONFIRM",
    "qualifier": "PIC",
    "deliveryDocument": "8001234567",
    "carrier": "ABC123",
    "items": [
      {
        "deliveryDocumentItem": "10",
        "sequenceNumber": "000",
        "material": "MAT-1000",
        "pickedQuantity": 8,
        "deliveryQuantityUnit": "EA"
      }
    ]
  }
}
```

## FSD decisions intentionally kept configurable

- The final S/4 HTTP/OData destination and production adapter are environment-specific.
- Carrier, plant, and storage-location mismatch policies remain disabled pending functional decisions.
- Retry count, timeout, idempotency retention, and alert recipients remain operational decisions.
- The FSD specifies `ConfirmPickingOneItem` or `ConfirmPickingAllItems`; this implementation uses one-item confirmation for a single non-zero item and all-items otherwise.
- Final acknowledgement to webMethods is represented as transport acknowledgement only.

## Production adapter work

Replace or extend `srv/lib/s4-adapter.js` with calls to the approved BTP destination and `ZAPI_LE_OUTB_DELIVERY_V2`. Production authorization, connectivity, and rollback semantics must be confirmed before enabling it. `PostGoodsIssue` and `PickOneItemWithBaseQuantity` are intentionally not used.
