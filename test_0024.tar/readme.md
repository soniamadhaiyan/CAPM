# Getting Started

Welcome to your new CAP project.

It contains these folders and files, following our recommended project layout:

File or Folder | Purpose
---------|----------
`app/` | content for UI frontends goes here
`db/` | your domain models and data go here
`srv/` | your service models and code go here
`readme.md` | this getting started guide

## Next Steps

- Open a new terminal and run `cds watch`
- (in VS Code simply choose _**Terminal** > Run Task > cds watch_)
- Start with your domain model, in a CDS file in `db/`

## Learn More

Learn more at <https://cap.cloud.sap>.

# MARC Pick Confirmation to SAP S/4HANA

CAP implementation of `TV-TMP-MT-Design-Specification-RICEFW_JHPZ_158593_MARC_PickConf_S4`.

## Run locally

```sh
npm install
cds watch
```

The OData service is available under `/odata/v4/pick-confirmation`. Use `test/pick-confirmation.http` for an example request.

The local implementation uses a transactional mock S/4 adapter with sample delivery contexts from `test/data`. See `docs/FSD-implementation-notes.md` for implemented behavior and configuration items that remain environment- or project-specific.

## Validate

```sh
cds compile srv --for nodejs
cds deploy --to sqlite::memory: --with-mocks
```
