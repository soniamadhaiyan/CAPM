using {
  jnj.pickconfirmation as model
} from '../db/schema';

@path: '/pick-confirmation'
service PickConfirmationService {
  @readonly entity PickConfirmationMessages as projection on model.PickConfirmationMessages;
  @readonly entity PickConfirmationItems as projection on model.PickConfirmationItems;
  @readonly entity PickOperations as projection on model.PickOperations;

  action submitPickConfirmation(input : model.PickConfirmationInput) returns {
    messageId       : UUID;
    correlationId   : String(80);
    status          : String(20);
    duplicate       : Boolean;
    acknowledgedAt  : Timestamp;
  };

  action reprocessPickConfirmation(messageId : UUID) returns {
    messageId       : UUID;
    status          : String(20);
    duplicate       : Boolean;
    acknowledgedAt  : Timestamp;
  };
}
