import cds from '@sap/cds';
import { randomUUID } from 'node:crypto';
import { createS4Adapter } from './lib/s4-adapter.js';
import {
  createIdempotencyKey,
  normalizeItem,
  validateEnvelope,
} from './lib/validation.js';

const { SELECT, INSERT, UPDATE } = cds.ql;
const LOG = cds.log('pick-confirmation');
const activeDeliveries = new Map();

export default class PickConfirmationService extends cds.ApplicationService {
  adapter;

  async init() {
    this.adapter = await createS4Adapter();
    const {
      PickConfirmationMessages: Messages,
      PickConfirmationItems: Items,
      PickOperations: Operations,
      ProcessedMessages,
      DeliveryContexts,
      DeliveryItemContexts,
    } = this.entities;

    this.on('submitPickConfirmation', async req => {
      let input;
      try {
        input = { ...req.data.input, items: req.data.input?.items?.map(normalizeItem) };
        validateEnvelope(input);
        input.idempotencyKey = createIdempotencyKey(input);

        const prior = await this.#findPrior(ProcessedMessages, input.idempotencyKey);
        if (prior) return this.#result(prior.message_ID, input.correlationId, prior.outcome, true);

        const messageId = await this.#persistReceived(req, Messages, Items, Operations, input);
        const status = await this.#serializeByDelivery(input.deliveryDocument, () =>
          this.#processMessage({
            req, input, messageId, Messages, Items, Operations, ProcessedMessages,
            DeliveryContexts, DeliveryItemContexts,
          })
        );

        return this.#result(messageId, input.correlationId, status, status === 'Duplicate');
      } catch (error) {
        LOG.warn('Rejected pick confirmation', {
          code: error.code,
          correlationId: input?.correlationId,
          message: error.message,
        });
        req.reject(error.code === 'INVALID_QUANTITY' ? 400 : 422, error.message, [error.details].filter(Boolean));
      }
    });

    this.on('reprocessPickConfirmation', async req => {
      const message = await SELECT.one.from(Messages, req.data.messageId);
      if (!message) return req.reject(404, 'Pick confirmation message not found.');
      if (!['Failed', 'HeldForReprocessing'].includes(message.status)) {
        return req.reject(409, 'Only failed or held messages can be reprocessed.');
      }

      const sourceItems = await SELECT.from(Items).where({ message_ID: message.ID });
      const input = {
        correlationId: `${message.correlationId}-reprocess-${Date.now()}`,
        messageType: message.messageType,
        qualifier: message.qualifier,
        deliveryDocument: message.deliveryDocument,
        carrier: message.carrier,
        idempotencyKey: `${message.idempotencyKey}-reprocess-${Date.now()}`,
        items: sourceItems.map(({ deliveryDocumentItem, sequenceNumber, material, plant, storageLocation, batch, pickedQuantity, deliveryQuantityUnit }) => ({
          deliveryDocumentItem, sequenceNumber, material, plant, storageLocation, batch, pickedQuantity, deliveryQuantityUnit,
        })),
      };
      const messageId = await this.#persistReceived(req, Messages, Items, Operations, input);
      const status = await this.#serializeByDelivery(input.deliveryDocument, () =>
        this.#processMessage({
          req, input, messageId, Messages, Items, Operations, ProcessedMessages,
          DeliveryContexts, DeliveryItemContexts,
        })
      );
      return this.#result(messageId, input.correlationId, status, false);
    });

    return super.init();
  }

  async #persistReceived(req, Messages, Items, Operations, input) {
    const messageId = randomUUID();
    const receivedAt = new Date().toISOString();
    await req.run(INSERT.into(Messages).entries({
      ID: messageId,
      correlationId: input.correlationId,
      messageType: input.messageType,
      qualifier: input.qualifier,
      deliveryDocument: input.deliveryDocument,
      carrier: input.carrier || null,
      idempotencyKey: input.idempotencyKey,
      status: 'Received',
      receivedAt,
    }));

    for (const item of input.items) {
      await req.run(INSERT.into(Items).entries({
        ...item,
        ID: randomUUID(),
        message_ID: messageId,
        status: 'Planned',
      }));
    }
    return messageId;
  }

  async #processMessage(context) {
    const { req, input, messageId, Messages, Items, Operations, ProcessedMessages } = context;
    await req.run(UPDATE(Messages, messageId).with({ status: 'Processing', processingStartedAt: new Date().toISOString() }));

    try {
      const delivery = await this.adapter.readDeliveryContext(input.deliveryDocument);
      if (!delivery) throw Object.assign(new Error('Outbound delivery not found.'), { code: 'INVALID_DELIVERY' });

      const planned = await this.#planOperations(req, input, delivery, Items, messageId);
      for (const operation of planned) {
        await req.run(INSERT.into(Operations).entries({
          ID: randomUUID(),
          message_ID: messageId,
          item_ID: operation.itemId,
          operation: operation.type,
          status: 'Planned',
        }));
      }

      await this.adapter.executeAtomicBatch(planned);
      await req.run(UPDATE(Messages, messageId).with({
        status: 'Completed', completedAt: new Date().toISOString(), rollbackCompleted: false,
      }));
      await req.run(UPDATE(Items).set({ status: 'Succeeded' }).where({ message_ID: messageId }));
      await req.run(UPDATE(Operations).set({ status: 'Succeeded', completedAt: new Date().toISOString() }).where({ message_ID: messageId }));
      await this.#recordOutcome(req, ProcessedMessages, input, messageId, 'Completed');
      return 'Completed';
    } catch (error) {
      const rollbackCompleted = Boolean(error.rollbackCompleted ?? true);
      await req.run(UPDATE(Messages, messageId).with({
        status: 'Failed', completedAt: new Date().toISOString(), errorCode: error.code || 'PROCESSING_ERROR',
        errorMessage: error.message, rollbackCompleted,
      }));
      await req.run(UPDATE(Items).set({ status: rollbackCompleted ? 'RolledBack' : 'Failed' }).where({ message_ID: messageId }));
      await req.run(UPDATE(Operations).set({ status: rollbackCompleted ? 'RolledBack' : 'Failed', errorMessage: error.message }).where({ message_ID: messageId }));
      LOG.error('Pick confirmation failed; complete-message rollback required', {
        correlationId: input.correlationId,
        deliveryDocument: input.deliveryDocument,
        code: error.code,
        error: error.message,
      });
      await this.#recordOutcome(req, ProcessedMessages, input, messageId, 'Failed');
      return 'Failed';
    }
  }

  async #planOperations(req, input, delivery, Items, messageId) {
    const storedItems = await req.run(SELECT.from(Items).where({ message_ID: messageId }));
    const byItem = new Map(delivery.items.map(item => [item.deliveryDocumentItem, item]));
    const planned = [];

    for (const item of input.items) {
      const stored = storedItems.find(candidate => candidate.deliveryDocumentItem === item.deliveryDocumentItem && candidate.sequenceNumber === item.sequenceNumber);
      const contextItem = byItem.get(item.deliveryDocumentItem);
      if (!contextItem || contextItem.deleted) throw this.#processingError('INVALID_DELIVERY_ITEM', `Delivery item ${item.deliveryDocumentItem} is not eligible.`);
      if (item.material && contextItem.material !== item.material) {
        throw this.#processingError('MATERIAL_MISMATCH', `Material mismatch for delivery item ${item.deliveryDocumentItem}.`, { expected: contextItem.material, received: item.material });
      }
      if (item.deliveryQuantityUnit !== contextItem.deliveryQuantityUnit) {
        throw this.#processingError('UOM_MISMATCH', `Delivery UoM mismatch for item ${item.deliveryDocumentItem}.`, { expected: contextItem.deliveryQuantityUnit, received: item.deliveryQuantityUnit });
      }
      if (contextItem.materialIsBatchManaged && item.sequenceNumber === '001' && !item.batch) {
        throw this.#processingError('BATCH_REQUIRED', `Batch is required for batch split item ${item.deliveryDocumentItem}.`);
      }
      if (!contextItem.materialIsBatchManaged && item.batch) {
        throw this.#processingError('BATCH_NOT_ALLOWED', `Batch must be blank for non-batch-managed item ${item.deliveryDocumentItem}.`);
      }
      if (contextItem.materialIsBatchManaged && contextItem.batch && item.batch && item.batch !== contextItem.batch) {
        throw this.#processingError('BATCH_MISMATCH', `Batch mismatch for item ${item.deliveryDocumentItem}.`);
      }
      if (item.pickedQuantity > contextItem.deliveryQuantity) {
        throw this.#processingError('QUANTITY_EXCEEDS_DELIVERY', `Picked quantity exceeds current delivery quantity for item ${item.deliveryDocumentItem}.`);
      }

      let type;
      if (item.pickedQuantity === 0) type = 'DeleteDeliveryItem';
      else if (item.sequenceNumber === '001') type = 'PickAndBatchSplitOneItem';
      else type = 'PickOneItemWithSalesQuantity';

      await req.run(UPDATE(Items, stored.ID).with({ plannedOperation: type }));
      planned.push({ type, input: item, itemId: stored.ID, context: { delivery, deliveryItem: contextItem } });
    }

    const nonZeroOperations = planned.filter(operation => operation.type !== 'DeleteDeliveryItem');
    if (nonZeroOperations.length === 1) {
      planned.push({ type: 'ConfirmPickingOneItem', input: {}, itemId: nonZeroOperations[0].itemId, context: nonZeroOperations[0].context });
    } else if (nonZeroOperations.length > 1) {
      planned.push({ type: 'ConfirmPickingAllItems', input: {}, itemId: nonZeroOperations[0].itemId, context: nonZeroOperations[0].context });
    }
    return planned;
  }

  async #findPrior(ProcessedMessages, idempotencyKey) {
    return SELECT.one.from(ProcessedMessages).where({ idempotencyKey });
  }

  async #recordOutcome(req, ProcessedMessages, input, messageId, outcome) {
    const completedAt = new Date();
    const expiresAt = new Date(completedAt.getTime() + 30 * 24 * 60 * 60 * 1000);
    await req.run(INSERT.into(ProcessedMessages).entries({
      idempotencyKey: input.idempotencyKey,
      correlationId: input.correlationId,
      deliveryDocument: input.deliveryDocument,
      outcome,
      message_ID: messageId,
      completedAt: completedAt.toISOString(),
      expiresAt: expiresAt.toISOString(),
    }));
  }

  async #serializeByDelivery(deliveryDocument, work) {
    const previous = activeDeliveries.get(deliveryDocument) || Promise.resolve();
    const current = previous.catch(() => {}).then(work);
    activeDeliveries.set(deliveryDocument, current);
    try {
      return await current;
    } finally {
      if (activeDeliveries.get(deliveryDocument) === current) activeDeliveries.delete(deliveryDocument);
    }
  }

  #processingError(code, message, details) {
    return Object.assign(new Error(message), { code, details, rollbackCompleted: true });
  }

  #result(messageId, correlationId, status, duplicate) {
    return { messageId, correlationId, status, duplicate, acknowledgedAt: new Date().toISOString() };
  }
}
